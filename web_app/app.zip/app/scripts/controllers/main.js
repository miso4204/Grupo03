'use strict';

/**
 * @ngdoc function
 * @name shirtsApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the shirtsApp
 */
angular.module('shirtsApp')
  	.controller('MainCtrl', function ($scope) {
  		
   	}
 );

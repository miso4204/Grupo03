'use strict';

/**
 * @ngdoc function
 * @name shirtsApp.controller:loginController
 * @description
 * #loginController
 * Controller of the shirtsApp
 */
angular.module('shirtsApp')
	.controller('loginController',['$scope', '$rootScope', '$location', 'AuthenticationService1',
		function($scope,$routeParams,$rootScope,$location,AuthenticationService1){
			$rootScope.authenticated = false;
			$scope.loginForm={};
			$scope.registerForm={};
			AuthenticationService1.ClearCredentials();
			$scope.login = function (credentials) {
				$scope.dataLoading = true;
				AuthenticationService1.Login(credentials,function(response) {
            		if(response.success) {
                		console.log("login responsed" + JSON.stringify(response))
                    	AuthenticationService.SetCredentials(credentials);
                    	$location.path('/catalog');
                	} else {
                    	$scope.error = response.message;
                    	$scope.dataLoading = false;
                    	console.log("error");
                	}
            	});
        	};
			$scope.getFieldCssClass=function(ngModelController){
				if(ngModelController.$pristine) return "";
				return ngModelController.$valid ? "valid-field" : "invalid-field";
			}
	}])

'use strict';

/**
 * @ngdoc function
 * @name shirtsApp.controller:productDetailCtrl
 * @description
 * #productDetailCtrl
 * Controller of the shirtsApp
 */

  angular.module('shirtsApp')
  	.controller('productDetailCtrl', function($scope,$routeParams){
  		$scope.productId=$routeParams.productId;

  		$scope.productInfo={
  			productId:'0000001',
			name:'Camiseta de Falcao', 
			price:'80.000', 
			averageRating:4, 
			ratings:48,
			availableColors:[
				{name:'rojo', code:'#A10000'},
				{name:'azul rey', code:'#3399FF'},
				{name:'azul', code:'#000080'},
			],
			availableSizes:[
				{name:'small',display:'S'}, 
				{name:'medium',display:'M'}, 
				{name:'large',display:'L'},
				{name:'xlarge',display:'XL'}
			],
			shippingPrice:'5',
			imgUrl:'http://www.realmadridjerseyspro.com/images/real_madrid/fc-real-madrid_267.jpg',
			images:[
				{
					image:'http://image-load-balancer.worldsportshops.com/Datafeeds/Graphics/Products/ImageCache/600x600/66368~FALCAO~9.RE02.jpg',
					text:'Frente'
				},
				{
					image:'http://image-load-balancer.worldsportshops.com/Datafeeds/Graphics/Products/ImageCache/600x600/66368~FALCAO~9.jpg',
					text:'Espalda'
				},
			],
			keyWords:['james','real madrid','futbol']
		}
		$scope.productOrder={
			productId:$scope.productId,
			selectedColor:{
				name:'',
				code:''
			},
			selectedSize:{
				name:''
			}
		}
  	})